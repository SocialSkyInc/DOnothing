oc start-build bezeq-cloud-smarttest-service --from-dir=. --follow
oc deploy bezeq-cloud-smarttest-service --latest
