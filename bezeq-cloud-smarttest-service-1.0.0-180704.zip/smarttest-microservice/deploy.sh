oc new-build --binary --name=bezeq-cloud-smarttest-service -l app=bezeq-cloud-smarttest-service
oc start-build bezeq-cloud-smarttest-service --from-dir=. --follow
oc new-app bezeq-cloud-smarttest-service -l app=bezeq-cloud-smarttest-service
oc expose service bezeq-cloud-smarttest-service -l vertx-cluster=true
