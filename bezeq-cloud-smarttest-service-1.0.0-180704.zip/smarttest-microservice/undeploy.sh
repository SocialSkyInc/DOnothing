oc delete all -l app=bezeq-cloud-smarttest-service
oc delete route bezeq-cloud-smarttest-service
