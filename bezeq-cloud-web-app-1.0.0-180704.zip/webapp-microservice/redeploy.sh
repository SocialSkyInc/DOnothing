oc start-build bezeq-cloud-web-app --from-dir=. --follow
oc deploy bezeq-cloud-web-app --latest
