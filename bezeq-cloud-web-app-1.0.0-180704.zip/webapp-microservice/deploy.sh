oc new-build --binary --name=bezeq-cloud-web-app -l app=bezeq-cloud-web-app
oc start-build bezeq-cloud-web-app --from-dir=. --follow
oc new-app bezeq-cloud-web-app -l app=bezeq-cloud-web-app
oc expose service bezeq-cloud-web-app -l vertx-cluster=true
