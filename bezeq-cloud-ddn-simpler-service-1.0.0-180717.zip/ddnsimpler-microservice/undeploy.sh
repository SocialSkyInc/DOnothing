oc delete all -l app=bezeq-cloud-ddn-simpler-service
oc delete route bezeq-cloud-ddn-simpler-service
