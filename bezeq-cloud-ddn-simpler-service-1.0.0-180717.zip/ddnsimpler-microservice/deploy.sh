oc new-build --binary --name=bezeq-cloud-ddn-simpler-service -l app=bezeq-cloud-ddn-simpler-service
oc start-build bezeq-cloud-ddn-simpler-service --from-dir=. --follow
oc new-app bezeq-cloud-ddn-simpler-service -l app=bezeq-cloud-ddn-simpler-service
oc expose service bezeq-cloud-ddn-simpler-service -l vertx-cluster=true
