oc start-build bezeq-cloud-ddn-simpler-service --from-dir=. --follow
oc deploy bezeq-cloud-ddn-simpler-service --latest
