oc delete all -l app=sy-ddn-simpler
oc delete route sy-ddn-simpler
