oc new-build --binary --name=sy-ddn-simpler -l app=sy-ddn-simpler
oc start-build sy-ddn-simpler --from-dir=. --follow
oc new-app sy-ddn-simpler -l app=sy-ddn-simpler
oc expose service sy-ddn-simpler -l vertx-cluster=true
