oc start-build sy-ddn-simpler --from-dir=. --follow
oc deploy sy-ddn-simpler --latest
