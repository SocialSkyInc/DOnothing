oc start-build bezeq-cloud-auth-service --from-dir=. --follow
oc deploy bezeq-cloud-auth-service --latest
