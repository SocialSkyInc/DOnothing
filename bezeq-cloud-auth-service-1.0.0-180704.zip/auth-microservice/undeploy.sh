oc delete all -l app=bezeq-cloud-auth-service
oc delete route bezeq-cloud-auth-service
