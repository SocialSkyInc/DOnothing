oc new-build --binary --name=bezeq-cloud-auth-service -l app=bezeq-cloud-auth-service
oc start-build bezeq-cloud-auth-service --from-dir=. --follow
oc new-app bezeq-cloud-auth-service -l app=bezeq-cloud-auth-service
oc expose service bezeq-cloud-auth-service -l vertx-cluster=true
