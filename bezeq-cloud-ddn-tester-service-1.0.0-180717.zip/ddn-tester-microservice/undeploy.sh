oc delete all -l app=bezeq-cloud-ddn-tester-service
oc delete route bezeq-cloud-ddn-tester-service
