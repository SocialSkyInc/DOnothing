oc start-build bezeq-cloud-ddn-tester-service --from-dir=. --follow
oc deploy bezeq-cloud-ddn-tester-service --latest
