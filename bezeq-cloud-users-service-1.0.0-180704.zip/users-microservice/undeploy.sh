oc delete all -l app=bezeq-cloud-users-service
oc delete route bezeq-cloud-users-service
