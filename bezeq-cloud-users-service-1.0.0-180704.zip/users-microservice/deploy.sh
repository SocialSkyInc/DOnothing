oc new-build --binary --name=bezeq-cloud-users-service -l app=bezeq-cloud-users-service
oc start-build bezeq-cloud-users-service --from-dir=. --follow
oc new-app bezeq-cloud-users-service -l app=bezeq-cloud-users-service
oc expose service bezeq-cloud-users-service -l vertx-cluster=true
