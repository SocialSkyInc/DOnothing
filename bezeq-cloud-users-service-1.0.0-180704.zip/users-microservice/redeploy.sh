oc start-build bezeq-cloud-users-service --from-dir=. --follow
oc deploy bezeq-cloud-users-service --latest
