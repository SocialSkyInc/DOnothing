oc delete all -l app=bezeq-cloud-activities-service
oc delete route bezeq-cloud-activities-service
