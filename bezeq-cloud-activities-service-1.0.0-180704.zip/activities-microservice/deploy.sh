oc new-build --binary --name=bezeq-cloud-activities-service -l app=bezeq-cloud-activities-service
oc start-build bezeq-cloud-activities-service --from-dir=. --follow
oc new-app bezeq-cloud-activities-service -l app=bezeq-cloud-activities-service
oc expose service bezeq-cloud-activities-service -l vertx-cluster=true
