oc start-build bezeq-cloud-activities-service --from-dir=. --follow
oc deploy bezeq-cloud-activities-service --latest
