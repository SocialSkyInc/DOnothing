oc delete all -l app=bezeq-cloud-storage-service
oc delete route bezeq-cloud-storage-service
