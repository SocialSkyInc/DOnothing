oc new-build --binary --name=bezeq-cloud-storage-service -l app=bezeq-cloud-storage-service
oc start-build bezeq-cloud-storage-service --from-dir=. --follow
oc new-app bezeq-cloud-storage-service -l app=bezeq-cloud-storage-service
oc expose service bezeq-cloud-storage-service -l vertx-cluster=true
