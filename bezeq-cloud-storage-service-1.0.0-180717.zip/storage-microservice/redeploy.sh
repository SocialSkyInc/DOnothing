oc start-build bezeq-cloud-storage-service --from-dir=. --follow
oc deploy bezeq-cloud-storage-service --latest
