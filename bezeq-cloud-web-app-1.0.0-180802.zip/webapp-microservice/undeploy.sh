oc delete all -l app=bezeq-cloud-web-app
oc delete route bezeq-cloud-web-app
