oc start-build bezeq-cloud-posts-service --from-dir=. --follow
oc deploy bezeq-cloud-posts-service --latest
