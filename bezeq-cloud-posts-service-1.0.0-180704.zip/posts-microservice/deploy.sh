oc new-build --binary --name=bezeq-cloud-posts-service -l app=bezeq-cloud-posts-service
oc start-build bezeq-cloud-posts-service --from-dir=. --follow
oc new-app bezeq-cloud-posts-service -l app=bezeq-cloud-posts-service
oc expose service bezeq-cloud-posts-service -l vertx-cluster=true
