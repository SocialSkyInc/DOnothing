oc delete all -l app=bezeq-cloud-posts-service
oc delete route bezeq-cloud-posts-service
