oc start-build bezeq-cloud-stream-service --from-dir=. --follow
oc deploy bezeq-cloud-stream-service --latest
