oc new-build --binary --name=bezeq-cloud-stream-service -l app=bezeq-cloud-stream-service
oc start-build bezeq-cloud-stream-service --from-dir=. --follow
oc new-app bezeq-cloud-stream-service -l app=bezeq-cloud-stream-service
oc expose service bezeq-cloud-stream-service -l vertx-cluster=true
