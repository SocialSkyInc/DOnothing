oc delete all -l app=bezeq-cloud-stream-service
oc delete route bezeq-cloud-stream-service
